package Day32.ConstructorTask2;

public class Square {
    int side;

    // No Arg
    public Square(){
        this.side = 55;
    }

    // with parameter
    public Square(int side){
        this.side = side;
    }
}
