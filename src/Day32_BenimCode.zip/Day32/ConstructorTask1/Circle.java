package Day32.ConstructorTask1;

public class Circle {

    int radius;

    // no-args constructor
    public Circle(){
        this.radius = 10;
    }

    // parametrized constructor
    public Circle(int radius){
        this.radius = radius;
    }

}

