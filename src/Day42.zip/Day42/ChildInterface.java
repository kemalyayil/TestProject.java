package Day42;
/*
if an interface needs to inherit from interface , use "Extends" key word.
if an interface inherits from interface, we should not  override all the methods.
Class can not have multiple inheritance. but interface can.
for the inheriting interface, it should not override all methods
 */


public interface ChildInterface extends ParentInterface{

}
