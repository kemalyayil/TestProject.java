package Day42;

public interface ParentInterface {
    void method();
    void method2();
}
