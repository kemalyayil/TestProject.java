package Day42.MultipleInheritance;

public interface Parent1 {

    int variable1 = 0;
    int variable2 = 0;

    void method1();
    void method2();
}
