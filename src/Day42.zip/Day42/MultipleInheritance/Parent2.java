package Day42.MultipleInheritance;

public interface Parent2 {
    int variable2 = 1;      // parent 1 da da var
    int variable3 = 1;

    void method2();         // parent 1 da da var
    void method3();
}
