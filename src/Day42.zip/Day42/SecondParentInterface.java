package Day42;

public interface SecondParentInterface {
}
