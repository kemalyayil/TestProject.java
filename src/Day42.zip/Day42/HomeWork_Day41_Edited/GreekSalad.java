package Day42.HomeWork_Day41_Edited;

public class GreekSalad extends Salad{

    @Override
    public void madeIn() {
        System.out.println("Made in Greece");
    }
}
