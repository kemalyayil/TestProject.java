package Day42.HomeWork_Day41_Edited;

public abstract class Food {

    public abstract void madeIn();
    public abstract void taste();


}
