package Day42.HomeWork_Day41_Edited;

public class DemoFood {


        public static void main(String[] args) {

            Cheesecake cheesecake = new Cheesecake();
            cheesecake.madeIn();
            cheesecake.taste();

            GreekSalad greekSalad = new GreekSalad();
            greekSalad.madeIn();
            greekSalad.taste();

        }

    }
