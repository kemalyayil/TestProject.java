package Day42.HomeWork_Day41_Edited;

class Cheesecake extends Sweet{   // public class Cheesecake extends Sweet di hocanin ki

    @Override
    public void madeIn() {
        System.out.println("Made in United States");
    }
}
