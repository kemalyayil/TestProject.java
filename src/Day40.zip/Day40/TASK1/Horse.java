package Day40.TASK1;

public class Horse extends Animal{


    @Override
    public void makeSound() {
        System.out.println("Neigh neigh");
    }
}
