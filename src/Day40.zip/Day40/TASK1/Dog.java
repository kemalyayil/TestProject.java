package Day40.TASK1;

public class Dog extends Animal{

    public Dog(){
        name = "Dog";
    }
    @Override
    public void makeSound() {
        System.out.println("HawHawHawwwww");
    }
}
