package Day40;

public class test {
}
