package Day40.Polymorphisim.RunTime2;

public class SportCar extends Vehicle{

    @Override
    String speedUpTo60() {
        return "SportCar is speeding up to 60 mph in 4 seconds!";
    }
}