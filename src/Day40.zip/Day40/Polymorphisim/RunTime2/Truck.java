package Day40.Polymorphisim.RunTime2;

public class Truck extends Vehicle{

    @Override
    String speedUpTo60() {
        return "Truck is speeding up to 60 mph in 15 seconds!";
    }
}
