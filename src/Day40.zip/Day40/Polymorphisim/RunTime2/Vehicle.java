package Day40.Polymorphisim.RunTime2;

public class Vehicle {

    String speedUpTo60(){
        return "Vehicle is speeding up to 60 mph!";
    }

}
