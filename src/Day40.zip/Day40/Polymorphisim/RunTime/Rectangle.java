package Day40.Polymorphisim.RunTime;

public class Rectangle extends Shape{


    @Override
    String display(){           // default modifiers : can be accessed in the same class and package
        return "Rectangle";
    }


}
