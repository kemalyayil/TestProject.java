package Day40.Polymorphisim.RunTime;

public class Circle extends Shape{
    @Override
    String display(){
        return "Circle";
    }

}
