package Day40.Polymorphisim.RunTime;

public class Shape {
    String display(){
        return "Shape";
    }
}
