package Day34;

public class Car {

    String name ;
    final int year;

    Car(int year){
        this.year=year;    // bunu yazdiktan sonra line 6 daki year duzeldi. yoksa kirmiziydi
    }
}
