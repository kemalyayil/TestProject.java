package Day34.ENUMS;

enum Days {   // enums are multiple constants (not changing)  final variables of lists.


    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY


}
