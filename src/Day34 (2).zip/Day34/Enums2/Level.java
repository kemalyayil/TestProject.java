package Day34.Enums2;

enum Level {

    Low,
    Medium,
    High,

}
