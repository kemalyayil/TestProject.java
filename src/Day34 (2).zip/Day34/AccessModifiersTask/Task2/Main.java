package Day34.AccessModifiersTask.Task2;

public class Main {
    public static void main(String[] args) {

       // Student student = new Student(); // private constructor, we must initialize

        Student student = new Student("Jack", 20);


        // not available because they are private.
//        student.name;
//        int age = student.age;

    }
}
