package Day34.AccessModifiersTask.Task1.SameTask1;

public class Main {
    ClassOne classOne = new ClassOne();  // public
    ClassTwo classTwo = new ClassTwo();  // package-proivate or default
}
