package Day34.AccessModifiersTask.Task1.SameTask1;

class ClassTwo {   // package-private class
}
