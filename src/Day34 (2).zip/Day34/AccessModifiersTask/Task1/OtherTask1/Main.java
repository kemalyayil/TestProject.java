package Day34.AccessModifiersTask.Task1.OtherTask1;

import Day34.AccessModifiersTask.Task1.SameTask1.ClassOne;

public class Main {
    public static void main(String[] args) {

        ClassOne classOne = new ClassOne();

        //ClassTwo classTwo = new ClassTwo();    // cant be accessed cuz default class
    }
}
