package Day34.AccessModifiersTask.Task3.Package2;

//import Day34.AccessModifiersTask.Task3.Package1.*;

public class Main {
    public static void main(String[] args) {

      // A a = new A(); // package private (defoult) oldugu icin olusturamayiz.
    }
}
