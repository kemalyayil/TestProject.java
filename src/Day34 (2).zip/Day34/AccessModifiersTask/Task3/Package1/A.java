package Day34.AccessModifiersTask.Task3.Package1;

class A {

    public A (){
        System.out.println("Class A");
    }

}
