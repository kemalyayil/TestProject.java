package Day34._01_Task1;


public class Main {
    public static void main(String[] args) {
        System.out.println("600 Seconds to Minutes: " + TimeConverter.convertSecondsIntoMinutes(600));
        System.out.println("20 Minutes to Seconds: " + TimeConverter.convertMinutesIntoSeconds(20));
        System.out.println("60 Minutes to Hours: " + TimeConverter.convertMinutesIntoHours(60));
        System.out.println("7 Hours to Minutes: " + TimeConverter.convertHoursIntoMinutes(7));

    }

}
