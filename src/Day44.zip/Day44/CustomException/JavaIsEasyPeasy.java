package Day44.CustomException;

public class JavaIsEasyPeasy extends Exception{


}
