package Day44;

public class _02_TryCatchFinally {

    public static void main(String[] args) {

        try {
            // try to do this
        }catch (Exception ex){
            // if there is an exception , do this.
        }finally {
            // do this anyway
        }


    }
}
