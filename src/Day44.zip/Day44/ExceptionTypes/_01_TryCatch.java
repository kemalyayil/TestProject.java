package Day44.ExceptionTypes;

public class _01_TryCatch {

    public static void main(String[] args) {

        try {
            // try to do this.
        } catch (Exception ex){
            // if there is an exception, do this
        }


    }

}
