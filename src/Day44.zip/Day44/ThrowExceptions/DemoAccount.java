package Day44.ThrowExceptions;

public class DemoAccount {
    public static void main(String[] args) {

        Account account = new Account();
        account.deposit(1);

    }
}
