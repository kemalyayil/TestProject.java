package Day41._0_ReferanceVariables;

public class Square extends Rectangle{

    String getName(){
        return "Square";
    }

    double getSide(){
        return 5;
    }
}
