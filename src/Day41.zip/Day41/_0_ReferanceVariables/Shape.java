package Day41._0_ReferanceVariables;

public class Shape {
    String getName(){
        return "Shape";
    }

    void printShape(){
        System.out.println("Shape");
    }


}
