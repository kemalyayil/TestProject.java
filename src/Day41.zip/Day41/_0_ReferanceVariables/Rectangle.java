package Day41._0_ReferanceVariables;

public class Rectangle extends Shape{
    String getName(){
        return "Rectangle";
    }

    double getLength(){
        return 3;
    }
}
