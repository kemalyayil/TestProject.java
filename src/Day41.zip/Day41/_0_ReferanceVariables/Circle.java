package Day41._0_ReferanceVariables;

public class Circle extends Shape{
    String getName(){
        return "Circle";
    }


    }

