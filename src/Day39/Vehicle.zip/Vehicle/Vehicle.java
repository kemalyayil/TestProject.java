package Day39.Vehicle;

public class Vehicle {
    String make;
    String model;

    public Vehicle(String make, String model){
        this.make = make;
        this.model = model;

    }

    public void speedUpTo60(){

    }

    public void breakDownFrom60(){

    }


}
