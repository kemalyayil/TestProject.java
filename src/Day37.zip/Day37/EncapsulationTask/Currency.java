package Day37.EncapsulationTask;

public enum Currency {
    USD,
    EUR;
}
