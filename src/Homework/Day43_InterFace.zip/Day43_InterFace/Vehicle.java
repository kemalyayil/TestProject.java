package Homework.Day43_InterFace;

public interface Vehicle {

    void speed();

}
