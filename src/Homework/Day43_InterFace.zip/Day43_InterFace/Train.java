package Homework.Day43_InterFace;

public class Train implements Vehicle{

    @Override
    public void speed() {
        System.out.println("Trains' speed is less than cars' ");
    }
}
