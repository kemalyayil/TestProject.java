package Homework.Day43_InterFace;

public class Car implements Vehicle {

    @Override
    public void speed() {
        System.out.println("Each cars speed limit is distinct");
    }
}
