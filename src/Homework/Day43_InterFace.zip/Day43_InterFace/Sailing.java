package Homework.Day43_InterFace;

public interface Sailing {
    void sail();
}
