package Homework.Day43_InterFace;

public interface Flying {
    void fly();
}
