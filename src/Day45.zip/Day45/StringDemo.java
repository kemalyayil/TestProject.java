package Day45;

public class StringDemo {
    public static void main(String[] args) {
        // Strings are immutable which means not changeable
        String str = "TechnoStudy";

        str.concat(" - Java");              // will create a new object

        System.out.println(str);


    }
}
