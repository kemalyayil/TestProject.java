package Day45.ExceptionsTasks.TASK4;

public class ExceptionTask4 extends Exception {
    /**
     Create a custom "Checked Exception"
     Create a method which throws your custom exception
     */


}
