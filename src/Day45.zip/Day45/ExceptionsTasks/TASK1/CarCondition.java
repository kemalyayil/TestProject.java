package Day45.ExceptionsTasks.TASK1;

public enum CarCondition {
    NEW, MEDIUM, OLD, WASTE;



}
