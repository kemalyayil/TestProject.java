package Day32.ConstructorTask3;

public class MainRectangle {
    public static void main(String[] args) {

        Rectangle rectangle = new Rectangle(7,3);
        int area = rectangle.area();
        System.out.println("area = " + area);
    }
}
