package Day32.ConstructorTask3;

public class Rectangle {

    int width;
    int length;

    public Rectangle(int width,int length){
        this.width = width;
        this.length = length;

    }
    public int area(){
        return width * length;
    }
}
