package Day4;

public class StringDataType {

    public static void main(String[] args) {
        String schoolName = "TechnoStudy";

        System.out.println(schoolName);
    }

}
