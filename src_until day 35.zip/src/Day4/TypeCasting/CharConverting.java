package Day4.TypeCasting;

public class CharConverting {

    public static void main(String[] args) {

        char m = 'M';
        System.out.println(m);
        int charM = m;
        System.out.println(charM); //bir daha bak. bakildi ve anlasildi. soyleki: char kullanirken
                                    // esittirden sonra '' karakterini kullandik(normal olarak)
                                    // YANLISIM: integer kullanirken esittirden sonra m harfini ''
                                    // single koat a almisim. ondan dolayi 109 cikiyormus 77 cikacagina.


    }
}
