package Day21;

public class _04_AutoboxingAndUnboxing {
    public static void main(String[] args) {
        Byte mybyte = 2;
        byte unboxing = mybyte;
        Byte autoBoxing = unboxing;
    }
}
