package Day21;

public class _03_WrapperClassTask {
    public static void main(String[] args) {
        Byte mybyte = 2;
        byte unboxing = mybyte;
        Byte autoBoxing = unboxing;

        Short myShort = 99;
        Integer myInteger = 886632;
        Long myLong = 99827L;
        Float myFloat = 776.22F;
        Double myDouble = 882626.22;
        Character myChar = 'K';
        Boolean myBoolean = true;

    }
}
