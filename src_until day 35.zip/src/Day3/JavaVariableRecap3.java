package Day3;

public class JavaVariableRecap3 {

    public static void main(String[] args) {

        int age =25;   // this is initializing
        int age2;  // this is only declaring
        age2 = 45;
        System.out.println(age2);


//        int x; // always initialize before reading
//        System.out.println(x);

    }
}
