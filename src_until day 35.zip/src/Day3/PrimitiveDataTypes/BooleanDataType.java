package Day3.PrimitiveDataTypes;

public class BooleanDataType {

    public static void main(String[] args) {

        boolean isItRaining = false;
        System.out.println(isItRaining);

        boolean isEligible = true;
        System.out.println(isEligible);
    }
}
