package Day3.PrimitiveDataTypes;

public class ByteDataType {

    public static void main(String[] args) {

//        int age = 30; we dont have to use int to store someones age.
//        niye, cunku byte daha az yer kapliyor. byte 1, int 4
        byte age = 30;
        System.out.println(age);

        byte myFirstByte = 54;
        byte mySecondByte = -76;
        System.out.println(myFirstByte);
        System.out.println(mySecondByte);

        byte maxValue = 127;
        byte minValue = -128;

        byte b = 10;
        System.out.println("byte:" + b);


    }
}
