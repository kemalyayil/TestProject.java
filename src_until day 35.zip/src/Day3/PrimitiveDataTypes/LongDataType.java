package Day3.PrimitiveDataTypes;

public class LongDataType {


    public static void main(String[] args) {

        long viewCount = 312345667890L;
        System.out.println(viewCount);

        long myFirstLong = 76_527_384_910L;
        long mySecondLong = -6_876_654_458L;
        System.out.println(myFirstLong);
        System.out.println(mySecondLong);

        long maxValue = 9_223_372_036_854_775_807L;
        long minValue = -9223372036854775808L;
        System.out.println(maxValue);
        System.out.println(minValue);
    }
}
