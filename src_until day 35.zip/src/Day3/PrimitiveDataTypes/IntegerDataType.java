package Day3.PrimitiveDataTypes;

public class IntegerDataType {

    public static void main(String[] args) {

        int youtubeViews = 200_000_000;
        System.out.println(youtubeViews);

        int myFirstInteger = 123456789;
        int mySecondInteger = -98765432;

        System.out.println(myFirstInteger);
        System.out.println(mySecondInteger);

    }

}
