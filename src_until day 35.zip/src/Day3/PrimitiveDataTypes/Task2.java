package Day3.PrimitiveDataTypes;

public class Task2 {

    public static void main(String[] args) {

        float pNumber = 3.14F;
        System.out.println(pNumber);

        double km = 5588.275;
        System.out.println(km);

        char Initials ='I';
        System.out.println(Initials);

        boolean canChickensFly = false;
        System.out.println(canChickensFly);

    }
}
