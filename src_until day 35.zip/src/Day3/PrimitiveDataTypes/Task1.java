package Day3.PrimitiveDataTypes;

public class Task1 {

    public static void main(String[] args) {

        byte fileSize = 100;
        System.out.println(fileSize);

        int secondsInYear = 30_008_275;
        System.out.println(secondsInYear);

        long cellsInBody = 1234556788987778999L;
        System.out.println(cellsInBody);

        short downloadSpeed = 30;
        System.out.println(downloadSpeed);



    }
}
