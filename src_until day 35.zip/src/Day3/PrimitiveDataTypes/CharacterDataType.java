package Day3.PrimitiveDataTypes;

public class CharacterDataType {

    public static void main(String[] args) {

       //it should be single character
        char somethingFromKeyboard = '#';

        System.out.println(somethingFromKeyboard);

        char letter = 'k';
        System.out.println(letter);

        char escapeChar = '\'';
        System.out.println(escapeChar);
    }


}
