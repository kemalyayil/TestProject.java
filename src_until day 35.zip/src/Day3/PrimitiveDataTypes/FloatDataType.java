package Day3.PrimitiveDataTypes;

public class FloatDataType {

    public static void main(String[] args) {

        float computerPrice = 799.99F;
        System.out.println(computerPrice);



        System.out.println("Max value for float: "+ Float.MAX_VALUE);
        System.out.println("Min value for float: "+ Float.MIN_VALUE);
        System.out.println("Min value for float: "+ Byte.MIN_VALUE);
        System.out.println("Min value for float: "+ Byte.MAX_VALUE);


    }
}
