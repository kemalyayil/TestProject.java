package Day3.PrimitiveDataTypes;

public class ShortDataType {

    public static void main(String[] args) {

        short currentYear = 2021;
        System.out.println(currentYear);

        short myFirstShort = 5673;
        short mySecondShort = -876;
        System.out.println(myFirstShort);
        System.out.println(mySecondShort);

        short maxValue =  32767;
        short minValue =  -32768;
        System.out.println(maxValue);
        System.out.println(minValue);

    }
}
