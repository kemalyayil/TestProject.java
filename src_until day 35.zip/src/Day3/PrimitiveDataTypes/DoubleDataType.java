package Day3.PrimitiveDataTypes;

public class DoubleDataType {

    public static void main(String[] args) {

        double mileage = 9995.786;
        System.out.println(mileage);

        System.out.println("Max value for double: "+ Double.MAX_VALUE);
        System.out.println("Min value for double: "+ Double.MIN_VALUE);

        double price = 5;
        System.out.println(price);
// yukardaki gibi tek rakam oldugunda run isleminden sonra 5.0 yazacaktir.otomatik olarak convert edecektir.

    }
}
