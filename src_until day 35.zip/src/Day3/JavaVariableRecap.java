package Day3;

public class JavaVariableRecap {

    public static void main(String[] args) {

        int mile = 50;

        int age = 30, temperature =28;

//        System.out.println(age);
//        System.out.println(temperature);

        int year = 2010;
        System.out.println(year);
        year = 2015;
        System.out.println(year);

        int yearBeforeWorldCup2313 = 2021;
        int _ = 45;
        int $ = 78;
        

    }
}
