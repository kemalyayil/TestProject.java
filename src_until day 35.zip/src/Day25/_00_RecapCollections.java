package Day25;

public class _00_RecapCollections {

/*

                        Array VS ArrayList
            - ArrayList is resizable, Array is fixed-size
            - Array can store both primitive and reference, ArrayList can only store reference
            - Use length in Array, size method in ArrayList
            - Both can duplicate elements


                        ArrayList VS Set
            - Set is unordered, ArrayList uses insertion order
            - Set doesn't allow duplicate values, ArrayList allows duplicates


                            TreeSet
            - It is an ordered set (using natural order - ascending order)

                            LinkedHashSet
            - It is using insertion order

                            HashSet
            - Unordered set


            *** We cannot use get method with Sets!!!!

     */



    }


