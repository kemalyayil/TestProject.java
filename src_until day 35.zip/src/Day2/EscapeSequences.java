package Day2;

public class EscapeSequences {
    public static void main(String[] args) {
        System.out.println("I learn \"Java\" in TechnoStudy");
        System.out.println("C:\\ProgramFiles\\...");
        System.out.println("Java is good \nprogramming language");
        System.out.println("\tTecnoStudy");
        System.out.println("TECHNO\nS\nT\nU\nD\nY");

    }
}
