package Day2;

public class task2 {
    public static void main(String[] args) {

        System.out.print("T");
        System.out.print("E");
        System.out.print("C");
        System.out.print("N");
        System.out.println("O");

        System.out.println("S");
        System.out.println("T");
        System.out.println("U");
        System.out.println("D");
        System.out.println("Y");
    }
}