package Day2;

public class Task1 {
    /*
    nice
    nice
    nice
     */
}
