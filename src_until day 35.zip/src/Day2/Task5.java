package Day2;

public class Task5 {
    public static void main(String[] args) {
        int studentsInClass = 25;
        studentsInClass = 24;

        System.out.println(studentsInClass);//update edilen bilgi studentsInClass
    }
}
