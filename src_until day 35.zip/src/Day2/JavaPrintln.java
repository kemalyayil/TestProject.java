package Day2;

public class JavaPrintln {
    public static void main(String[] args) {
        System.out.println("TechnoStudy1");
        System.out.println("TechnoStudy2");
        System.out.println("TechnoStudy3");
        System.out.println("TechnoStudy4");
        System.out.println("TechnoStudy5");

        System.out.print("Day1");
        System.out.print("Day2");
        System.out.print("Day3");
        System.out.print("Day4");
        System.out.print("Day5");
    }
}
