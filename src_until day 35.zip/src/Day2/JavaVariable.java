package Day2;

public class JavaVariable {
    public static void main(String[] args) {
        int age = 30;
        System.out.println("age");
    }
}
