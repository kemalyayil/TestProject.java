package Day2;

public class JavaVariable2 {
    public static void main(String[] args) {
        int age = 30;
        int temperature = 25;

        int myAge = 27;
        int herAge = myAge;
        System.out.println(herAge);
    }

}
