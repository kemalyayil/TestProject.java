package Day23;

public class Calis_ForEachLoop {
    public static void main(String[] args) {
        int [] myArray = {4,5,6,7,8};
        for (int gezin : myArray){      // for each loop un kullanimi. "gezin" variable.
            System.out.println(gezin);
        }
        System.out.println(" ");
    }


}
