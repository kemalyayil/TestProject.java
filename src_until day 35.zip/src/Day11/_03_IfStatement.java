package Day11;

public class _03_IfStatement {
    public static void main(String[] args) {

        if (true){  // true yazdigimiz icin , print ettigimizde yazar.
            System.out.println("This is true1");
        }
        if (false) {  // false yazdigimiz icin , print ettigimizde yazmaz.
            System.out.println("This is true2");
        }
        }

}
