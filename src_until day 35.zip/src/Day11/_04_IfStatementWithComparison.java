package Day11;

public class _04_IfStatementWithComparison {

    public static void main(String[] args) {

        int numberOfStudents = 100;

        if (numberOfStudents < 10){
            System.out.println("Less than 10 students in class");
        }

        if (numberOfStudents > 10){
            System.out.println("More than 10 students");
        }

        if (numberOfStudents == 10){
            System.out.println("Number of students 10");
        }
    }
}
