package Mentoring;

public class _01_ {

    public static void main(String[] args) {

        int number = 100;
        System.out.println("number = " + number); //soutv: last variable that you created will be placed.

    }
}
