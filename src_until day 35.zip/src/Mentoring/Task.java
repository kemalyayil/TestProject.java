package Mentoring;

public class Task {


}
