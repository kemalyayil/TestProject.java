package Mentoring;

public class ArrayWithYuan {
    public static void main(String[] args) {
//        String[] cars = { "BMW", "Toyota", "Tesla"};
//        System.out.println(cars[0]);
//        cars[0] = cars[0].replace(cars[0].charAt(2),'-');
//        cars[1] = cars[1].replace(cars[1].charAt(2),'-');
//        cars[2] = cars[2].replace(cars[2].charAt(2),'-');
//        System.out.println(cars[0]);
//        System.out.println(cars[1]);
//        System.out.println(cars[2]);

        String number = "My phone number is 678.571.5657";
        String replace1 = number.replaceAll(".","-");
        System.out.println("replace1 = " + replace1);













    }
}
