package Homework;

public class HomeWork3 {
    //Assignment - Java Byte Data Type - Homework

    public static void main(String[] args) {

        byte five = 5;
        System.out.println(five);

        byte minusFour = -4;
        System.out.println(minusFour);


        System.out.println("Maximum value of \"byte\" is " +Byte.MAX_VALUE);
        System.out.println("Minimum value of \"byte\" is " +Byte.MIN_VALUE);
        byte maxValue = 127;
        System.out.println(maxValue);
        byte minValue = -128;
        System.out.println(minValue);




    }
}
