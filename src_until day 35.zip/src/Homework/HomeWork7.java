package Homework;
public class HomeWork7 {
    //Assignment - Java Double Data Type - Homework
      public static void main(String[] args) {
        double currentDollarRate = 120.005998654;
        double maxSpeed = 174;
        double inflationRate = -4.00555999;
          System.out.println(currentDollarRate);
          System.out.println(maxSpeed);
          System.out.println(inflationRate);
          System.out.println(currentDollarRate + "\n" + maxSpeed + "\n" + inflationRate);
          System.out.println("Max value of double =" +Double.MAX_VALUE);
          System.out.println("Min value of double =" +Double.MIN_VALUE);
    }
}
