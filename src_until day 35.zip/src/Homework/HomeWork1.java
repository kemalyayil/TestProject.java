package Homework;

public class HomeWork1 {

    //Assignment - Java Boolean Data Type - Homework
    public static void main(String[] args) {

        boolean isMessiFromArgentina = true;
        System.out.println(isMessiFromArgentina);

        boolean isTechnoStudyBad = false;
        System.out.println(isTechnoStudyBad);
    }
}
