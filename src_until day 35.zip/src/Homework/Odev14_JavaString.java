package Homework;

public class Odev14_JavaString {

    public static void main(String[] args) {

      //1- Create a String which is laptop. / Print that String
      String product = "laptop";
        System.out.println(product);

      // 2 -Create a String which is water. /Print that String
        String liquid = "water";
        System.out.println(liquid);

      // 3 - Create a String which is [techno study]/Print that String
        String schoolName = "techno study";
        System.out.println(schoolName);


    }
}
