package Homework;

public class Odev15JavaStringMethods {
    public static void main(String[] args) {

        // Create a String which is I love java. /  Print the total count of character count of that String
        String motto = "I love java";
        System.out.println(motto.length());

        //Create a String which is Sprint  /  Print the total count of character count of that String
        String aTermInJava = "Sprint";
        System.out.println(aTermInJava.length());

        // Create a String which is paper. / Make the String upper case and print the string
        String weWriteOnIt = "paper";
        System.out.println(weWriteOnIt.toUpperCase());

        // Create a String which is OraNge./ Make the String lower case and print the string
        String color = "OraNge";
        System.out.println(color.toLowerCase());

        // Create a String which is New Jersey. // Make the String upper case and print the string
        String destination = "New Jersey";
        System.out.println(destination.toUpperCase());

        //Create a String which is New York. /Make the String Lower case and print the string.
        String nuevoYork = "New York";
        System.out.println(nuevoYork.toLowerCase());

        //Create a String which is PADDLE. / Make the String lower case and print the string.
        String actionInBoat = "PADDLE";
        System.out.println(actionInBoat.toLowerCase());



    }
}
