package Homework.Homework35_Enum_Task1;

public class CheckFirst3Moths {

    Months months;

    public CheckFirst3Moths(Months months){
        this.months = months;
    }

    public Months getMonths(){
        return months;
    }
}
