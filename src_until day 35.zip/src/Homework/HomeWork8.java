package Homework;
public class HomeWork8 {
        //Assignment - Java Type Casting: Implicit Casting - Homework
    public static void main(String[] args) {
//        1- Create 2 variables byte & long | convert byte to long | print long
        byte ageOfRetiring = 65;
        long convertToLong = ageOfRetiring;
        System.out.println(convertToLong);

//        2- Create 2 variables float & double | convert float to double | print double
        float averageOfExams = 78.99F;
        double convertToDouble = averageOfExams;
        System.out.println(convertToDouble);

//        3- Create 2 variables int & double | convert int to double | print double
        int waterM3InDams = 3_553_344;
        double convertToDouble2 = waterM3InDams;
        System.out.println(convertToDouble2);
    }
}
