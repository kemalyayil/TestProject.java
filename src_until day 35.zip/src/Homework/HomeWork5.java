package Homework;

public class HomeWork5 {
        //    Assignment - Java Long Data Type - Homework
        public static void main(String[] args) {
            long telephoneNumber = 987_654_321L;
            long creationOfTheUniverseRoughly = -123_456_789L;

            System.out.println(telephoneNumber);
            System.out.println(creationOfTheUniverseRoughly);
            System.out.println(telephoneNumber + "\n" + creationOfTheUniverseRoughly);
            System.out.println("Max value for long =" +Long.MAX_VALUE);
            System.out.println("Min value for long =" +Long.MIN_VALUE);





        }
}
