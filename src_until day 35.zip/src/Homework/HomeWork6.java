package Homework;
public class HomeWork6 {
    // Assignment - Java Float Data Type - Homework
    public static void main(String[] args) {
        float angle = 121.005F;
        float freezingCapacityTill = -3.3365F;
        float earthquakeIntensity = 7.3365765F;
        System.out.println(angle);
        System.out.println(freezingCapacityTill);
        System.out.println(earthquakeIntensity);
        System.out.println(angle + "\n" + freezingCapacityTill + "\n" + earthquakeIntensity);
        System.out.println("Max value for float =" +Float.MAX_VALUE);
        System.out.println("Min value for float =" +Float.MIN_VALUE);



    }
}
