package Homework;

public class HomeWork2 {
    //Assignment - Java Char Data Type - Homework

    public static void main(String[] args) {
        char a = 'a';
        char a2 = 97;
        System.out.println(a);
        System.out.println(a2);

        char nine = '9';
        char nine2 = 57;
        System.out.println(nine);
        System.out.println(nine2);

        char and = '&';
        char and2 = 38;
        System.out.println(and);
        System.out.println(and2);

        char singleQuote = '\'';
        char singleQuote2 = 39;
        System.out.println(singleQuote);
        System.out.println(singleQuote2);

    }
}
