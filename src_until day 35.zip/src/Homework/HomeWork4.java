package Homework;

public class HomeWork4 {
    //  Assignment - Java Short Data Type - Homework
    public static void main(String[] args) {

        short rent$ = 750;
        System.out.println(rent$);
        short overDueFine = -100;
        System.out.println(overDueFine);
        System.out.println(rent$+"\n"+overDueFine);

        System.out.println("Min value for short =" +Short.MIN_VALUE);
        System.out.println("Max value for short =" +Short.MAX_VALUE);
        short minValue = -32768;
        short maxValue = 32767;
        System.out.println(minValue + "\n" + maxValue);


    }
}
