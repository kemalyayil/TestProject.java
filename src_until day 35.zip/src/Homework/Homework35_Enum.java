package Homework;

public class Homework35_Enum {
}
