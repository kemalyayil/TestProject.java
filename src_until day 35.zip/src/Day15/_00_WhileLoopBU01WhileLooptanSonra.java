package Day15;

public class _00_WhileLoopBU01WhileLooptanSonra {
    public static void main(String[] args) {

        while (true){
            System.out.println("This is a While Loop");
            // infinite printing
        }

        }
    }

