package Day15;

public class _01_Task {
    // count from 5 until 10 and print the numbers
    public static void main(String[] args) {
        int i = 5;
        while (i <= 10) {
            System.out.println(i);
            i++;
        }
    }
}
