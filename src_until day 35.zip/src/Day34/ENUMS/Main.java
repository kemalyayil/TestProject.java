package Day34.ENUMS;

public class Main {

    public static void main(String[] args) {

        Days firstDay = Days.MONDAY;
        System.out.println(firstDay);

        //ya da

        System.out.println(Days.MONDAY);


    }
}
