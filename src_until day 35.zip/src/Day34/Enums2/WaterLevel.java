package Day34.Enums2;

public class WaterLevel {

    Level level;

    public WaterLevel(Level level){
        this.level = level;
    }

    public Level getLevel(){
        return level;               // line 7
    }
}
