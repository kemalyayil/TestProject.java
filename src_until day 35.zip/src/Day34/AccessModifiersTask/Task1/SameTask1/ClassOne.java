package Day34.AccessModifiersTask.Task1.SameTask1;

public class ClassOne {
}
