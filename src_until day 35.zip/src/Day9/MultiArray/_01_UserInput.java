package Day9.MultiArray;

import java.util.Scanner;

public class _01_UserInput {
    public static void main(String[] args) {

        // it helps us to read the data
        Scanner userInput = new Scanner(System.in);
        String myString = userInput.nextLine();
        System.out.println(myString); //
        // asagida hic bi sey gorunmuyor. yazip enter a basinca asagi aynisini yapistiriyor



            }

}
