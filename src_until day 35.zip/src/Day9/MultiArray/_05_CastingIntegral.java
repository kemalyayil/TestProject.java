package Day9.MultiArray;

import java.util.Scanner;

public class _05_CastingIntegral {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Type your byte");
        byte myByte = (byte) scanner.nextLong(); // burada byte i long a convert ediyoruz
        System.out.println("myByte : " + myByte);




    }
}
