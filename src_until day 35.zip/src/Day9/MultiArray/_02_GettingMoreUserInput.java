package Day9.MultiArray;

import java.util.Scanner;

public class _02_GettingMoreUserInput {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("What's your name?");
        String name = scanner.nextLine();

        System.out.println("What's your age?");
        String age = scanner.nextLine();

        System.out.println("You are: " + name);
        System.out.println("Your age is: " + age);







    }


}
