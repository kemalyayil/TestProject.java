package Day13;

public class _04_TernaryOperator {
    public static void main(String[] args) {

//        boolean condition = true;

//        String result;
//
//        if (condition){
//            result = "result1";
//        } else{
//            result = "result2";
//        }

//        String result = condition ? "result1" : "result2";  // yukardakinin shortcut i


        int year = 2021;
//        int age ;
//
//        if (year == 2021){
//            age = 30;
//        } else {
//            age = 29;
//        }
        int age = year ==2021 ? 30 : 29;

    }
}
