package Day13;

public class _05_TernaryTask2 {
    public static void main(String[] args) {

        int temp = 7;
        String message = temp < 10 ? "cold" : "good";
        System.out.println(message);


    }
}
