package Day10;

public class _01_Addition {
    public static void main(String[] args) {

        // addition using only values (direct values)
        System.out.println(5+ 4);


        // addition of the variables
        int x = 1;
        int y = 2;
        System.out.println(x + y);


        // I store this value in another variable
        int result = x + y;
        System.out.println("result = " + result);



        // one variable and one value is also possible
        System.out.println(x + 7);



    }
}
