package Day10;

public class _01_AdditionTask {
    public static void main(String[] args) {

        // create a program the adds two numbers
        int one = 5;
        int two = 6;

        System.out.println(one + two);



    }
}
