package Day10;

public class _07_Modulus {
    public static void main(String[] args) {

        int x = 8 ;  //dividened. bolunen
        int y = 3 ;  // bolen
        System.out.println( x % y); // remainder from division. bolme isleminden sonra kalani hesapliyor

        System.out.println( 10 % 3); // burada 1 cikar sonuc. 3x3 = 9 , 10-9 =1

        System.out.println( 100 % 10); // burada remainder sifir cikar.




    }
}
