package Day10;

public class _03_Multiplication {

    public static void main(String[] args) {

        // Multiplication using values.
        System.out.println( 5 * 3);

        // Multiplication using variables.
        int x = 9 ;
        int y = 8 ;
        System.out.println(x * y);


        int result = x * y;
        System.out.println(result);

        //Multiplication using variables and values.
        System.out.println(result * 2);

        result = result *2;  // burada update ettik
        System.out.println(result);




    }
}
