package Day5;

public class StringCasting {

    public static void main(String[] args) {

        String number = "3";
        String number2 = "6";
        int sum = Integer.parseInt(number2) + 1;
        System.out.println(sum); //it is called "Wrapper Class"









    }
}
