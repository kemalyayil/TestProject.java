package Day5.StringMethods0;

public class _04_ToUpperCase {

    public static void main(String[] args) {

        String countryName = "United States of America";

        String countryNamesToUpper = countryName.toUpperCase();
        System.out.println(countryNamesToUpper);
        System.out.println(countryName.toUpperCase());
    }
}
