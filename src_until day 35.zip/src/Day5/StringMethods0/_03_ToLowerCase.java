package Day5.StringMethods0;

import java.util.Locale;

public class _03_ToLowerCase {

    public static void main(String[] args) {

        String countryName = "United States of America";
        String countryNameToLower = countryName.toLowerCase();
        System.out.println(countryNameToLower);
        System.out.println(countryName.toLowerCase());
    }
}
