package Day5.HumanClass;

public class Human {
}
