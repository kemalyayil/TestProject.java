package Day28.TaskPackage;

public class Cat {

    String name;
    int age;



    void sound(){
        System.out.println("Sound is MEOW");
    }

    void printAllProperties(){
        System.out.println("Name : " + name + " , Age : " + age);
    }
}
