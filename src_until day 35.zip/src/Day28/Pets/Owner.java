package Day28.Pets;

public class Owner {

    String name ;
    int age;
    String gender;

    void printProperties(){
        System.out.println("Name of the owner : " + name + " , Age : " + age + " , Gender : " + gender);
    }
}
