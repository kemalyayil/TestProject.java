package Day17;

public class _01_Task1 {
    public static void main(String[] args) {
            //****
            //****
            //****
            //****

        for (int i = 0; i < 4; i++){
            for (int j = 0 ; j < 4; j++){
                System.out.print("*");   // output ****
                                         // for each iteration
            }
            System.out.println(); // bunu yapmamizin nedeni asagi gecsin diye. i loopun ki bu.
        }


    }
}
