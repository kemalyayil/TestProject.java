package Day18;

public class _02_Methods {
    public static void main(String[] args) {

        // System.out.println("Hello World!");   normalde bu sekilde yapiyoruz

        printHelloWorld();

    }
    // void means method has no return type

    public static void printHelloWorld(){
        System.out.println("Hello World!");
    }
}
