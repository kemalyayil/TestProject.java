package Day18;

public class _02_Task {
    // create a simple public static void method to print "Hello World!" 5 times
    public static void main(String[] args) {

        greet();



    }

    public static void greet() {
        System.out.println("Hello World!");
        System.out.println("Hello World!");
        System.out.println("Hello World!");
        System.out.println("Hello World!");
        System.out.println("Hello World!");
    }
}
