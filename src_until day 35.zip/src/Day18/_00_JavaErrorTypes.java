package Day18;

public class _00_JavaErrorTypes {
    public static void main(String[] args) {
        // compile time error ( sytax error)
        // name = "Halit"  ===> basa String sona ; koymak gerekiyor.
        //System.out.println(Name);   == > burda da hata var. N buyuk yazildigi icin. case sensitive
        //System.out.println(Sinan);   == > burda da hata var. "" gerekiyor
        //System.out.println('Sinan');   == > burda da hata var. "" gerekiyor. '' icinde cok karekter var




    }
}
