package Day18;

public class _03_MethodsParameters2 {
    public static void main(String[] args) {

        greetUser("Kemal", "Yayil");


    }


    public static void greetUser(String firstName,String lastName) {
        System.out.println("Hello!" + firstName + " " + lastName);
    }

}
