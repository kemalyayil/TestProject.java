package Day14;

public class _01_Task2KEMAL {
    // for loops
    public static void main(String[] args) {

        // write a java program which calculates the sum from [0 to 5];
        // using for-loop

        int sum = 0;
        for (int i = 0; i < 5; ++i){
            sum += i;
        }
        System.out.println(sum);
    }
}
