package Day29.ReferenceVsPrimitive;

public class Person {
    String firstName;
    String lastName ;
    int age;

}
