package Day6;

public class Task1 {
    public static void main(String[] args) {
        /*
        // Part1: find out the length of String "123456789"
    // Part2: find out the length of String "0123456789"
         */
        String numbers = "123456789";
        int lengthOfNumbers = numbers.length();
        System.out.println(lengthOfNumbers);

        String numbers2 = "0123456789";
        int lengthOfNumbers2 = numbers2.length();
        System.out.println(lengthOfNumbers2);
    }
}
