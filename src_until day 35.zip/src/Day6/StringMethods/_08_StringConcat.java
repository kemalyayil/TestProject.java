package Day6.StringMethods;

public class _08_StringConcat {
    public static void main(String[] args) {

        String first = "Hello";
        String second = "TechnoStudy";
        String third = "!!";

        String concat = first.concat(second);
        String concat2 = concat.concat(third);
        System.out.println(concat2);




    }
}
