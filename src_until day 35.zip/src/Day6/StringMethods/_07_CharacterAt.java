package Day6.StringMethods;

public class _07_CharacterAt {

    public static void main(String[] args) {

        String welcome = "Hello TechnoStudy!";
        char index0 = welcome.charAt(0);
        char index1 = welcome.charAt(1);
        char index2 = welcome.charAt(2);
        char index3 = welcome.charAt(3);
        System.out.println(index0);
        System.out.println(index1);
        System.out.println(index2);
        System.out.println(index3);
        System.out.println("");
        System.out.println(welcome.charAt(0));
    }
}
