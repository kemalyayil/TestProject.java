package Day6.StringMethods;

public class _12_Contains {

    public static void main(String[] args) {

        String hello = "Hello World";
        System.out.println(hello.contains("H"));
        System.out.println(hello.contains("Hello"));
        System.out.println(hello.contains(" "));
        System.out.println(hello.contains("Z"));
        
    }
}
