package Day6;

public class Task6 {
    public static void main(String[] args) {
        // print your name in upper case
        String yourName = "kemal";
        String upperToYourName = yourName.toUpperCase();
        System.out.println(upperToYourName);    }
}
