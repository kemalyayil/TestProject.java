package Day6;

public class Task8 {
    public static void main(String[] args) {

        // Part1: concatenate string "01234" and "56789" with concat() function
        // Part2: concatenate string "01234" and "56789" using + operator

        String string1 = "01234";
        String string2 = "56789";

        System.out.println(string1.concat(string2));
        System.out.println(string1 + string2);  // buarada dogrudan yazdirabiliyoruz


    }
}
