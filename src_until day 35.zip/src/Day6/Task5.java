package Day6;

public class Task5 {
    public static void main(String[] args) {

        // convert "Hello TechnoStudy!" to lowercase letter

     String lowerCase = "Hello TechnoStudy!";
     String lowercaseTask = lowerCase.toLowerCase();
        System.out.println(lowercaseTask);

    }
}
