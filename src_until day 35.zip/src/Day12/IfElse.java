package Day12;

public class IfElse {
    public static void main(String[] args) {

        int  income = 10_000;
        if (income > 100_000){
            System.out.println("Your income is good");
        } else {
            System.out.println("Your income is not good");
        }


//        if (income < 100_000){  // normalde boyle yapiyorduk
//            System.out.println("Your income is not good");
//        }

    }
}
