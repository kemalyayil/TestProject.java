package Day33._01_Package.PackageOne;

class Plane {           /// burada public ibaresini sildik. defoult oldu. o pakete ozel oldu. paket disinda
                        // kullanilmaz

}
