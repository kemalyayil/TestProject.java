package Day33._01_Package.PackageOne;

public class MainClass {


    // I'm able access all of them
        Car car = new Car("Ford"); // public

        Truck truck = new Truck(); // public

        Plane plane = new Plane(); // default (package-private)

}
