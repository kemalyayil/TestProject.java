package Day33._01_Package.PackageOne;

public class Truck {



}
