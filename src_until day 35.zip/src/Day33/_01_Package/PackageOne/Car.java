package Day33._01_Package.PackageOne;

public class Car {

    String name;

    public Car(String name){

        this.name = name;
    }

    public String getName(){

        return name;
    }
    Car car = new Car("BMW");


}
