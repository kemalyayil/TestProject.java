package Day33._01_Package.PackageTwo;

import Day33._01_Package.PackageOne.Car;

public class Main2 {

    public static void main(String[] args) {

        Car car = new Car("BMW");

//        Truck truck = new Truck(); - not available because not imported

    }

}
