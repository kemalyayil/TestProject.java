package Day33._01_Package.PackageTwo;

public class Main3 {

    public static void main(String[] args) {

        Day33._01_Package.PackageOne.Car car = new Day33._01_Package.PackageOne.Car("Tesla");

    }
    
}
