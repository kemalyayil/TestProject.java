package Day33._02_InstanceModifiers.defaultModifier.other;

import Day33._02_InstanceModifiers.defaultModifier.same.Truck;

public class Main {

    public static void main(String[] args) {

//        Truck truck = new Truck();
//        String name = truck.name;
//        System.out.println(truck.getName());

//        the above will not be available because they are package-private(default)
//        the access modifiers are default for (field-constructor and method)


    }

}
