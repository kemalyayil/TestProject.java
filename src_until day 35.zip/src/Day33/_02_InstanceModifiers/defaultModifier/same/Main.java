package Day33._02_InstanceModifiers.defaultModifier.same;

public class Main {

    public static void main(String[] args) {

        Truck truck = new Truck();          // default deger. burada cagirabildik. cunku bu paket icinde oldugu icin.

        System.out.println(truck.name);

        System.out.println(truck.getName());


    }


}
