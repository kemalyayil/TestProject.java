package Day33._02_InstanceModifiers.defaultModifier.same;

public class Truck {

    String name;

    Truck(){

        name = "Ferrari";
    }

    String getName(){

        return name;
    }

}
