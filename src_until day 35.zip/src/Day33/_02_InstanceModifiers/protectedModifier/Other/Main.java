package Day33._02_InstanceModifiers.protectedModifier.Other;

import Day33._02_InstanceModifiers.protectedModifier.Same.Person;

public class Main {
    public static void main(String[] args) {

        // cunku baska bi package den cagiriyoruz

   //     Person person = new Person();     // protected oldugu icin ulasilamiyor.  // same pack, person class ,line 7

        // person.name;                    // same pack, person class
    }
}
