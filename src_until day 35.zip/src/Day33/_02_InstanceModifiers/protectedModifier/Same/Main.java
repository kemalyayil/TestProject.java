package Day33._02_InstanceModifiers.protectedModifier.Same;

public class Main {
    public static void main(String[] args) {
        Person person = new Person();
        System.out.println(person.name);
        System.out.println(person.getName());
    }
}
