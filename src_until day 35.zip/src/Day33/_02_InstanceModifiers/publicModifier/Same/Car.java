package Day33._02_InstanceModifiers.publicModifier.Same;

public class Car {

    public String name;

    public Car(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

}
