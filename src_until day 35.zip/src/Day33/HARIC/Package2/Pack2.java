package Day33.Package2;


public class Pack2 {

    //Accessing with fully qualified name(Full path)
    Day33.Package1.Pack1 pack1 = new Day33.Package1.Pack1();   // bu sekilde yukardaki gibi import etmeden(line 4-5) de ulasabiliriz


}
