package Day33;

public class Main {
    public static void main(String[] args) {    // public is access modifier which defines the access level

    }
}
