package Day33.Package1;

public class Pack1 {
}
