package Day7.JavaArrays;

import java.util.Arrays;

public class Task1 {
    public static void main(String[] args) {

        byte[] byteArray = new byte[3];
        byteArray[0] = 30;
        byteArray[1] = 20;
        byteArray[2] = 1;

        System.out.println(Arrays.toString(byteArray));




    }
}
