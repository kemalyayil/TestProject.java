package Day7.JavaArrays;

import java.util.Arrays;

public class Task2 {
    public static void main(String[] args) {

        //                          Task
        // declare an array of fruits and initialize it with some values | use array = {}
        // print all elements
        // print size of your Array

        String [] arrayOfFruit = {"Apple", "Banana", "Pear"};
        System.out.println(Arrays.toString(arrayOfFruit));
        System.out.println(arrayOfFruit.length);


    }
}
