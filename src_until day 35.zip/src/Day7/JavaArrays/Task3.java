package Day7.JavaArrays;

import java.util.Arrays;

public class Task3 {
    public static void main(String[] args) {

        double [] myArray = { 1000, 2000 , 3000, 4000};
        Arrays.sort(myArray);
        System.out.println(Arrays.toString(myArray));

    }
}
